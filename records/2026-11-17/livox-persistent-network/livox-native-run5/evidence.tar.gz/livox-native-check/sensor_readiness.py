"""Wait for fresh, progressing LiDAR and IMU before starting a LIO session."""
import math
import struct
import time


def wait_for_sensors(timeout=15., hold=1.):
    import rclpy
    from livox_ros_driver2.msg import CustomMsg
    from sensor_msgs.msg import Imu
    from rclpy.qos import qos_profile_sensor_data
    from rclpy.context import Context

    context = Context()
    rclpy.init(args=[], context=context)
    node = rclpy.create_node('lio_sensor_readiness', context=context)
    samples = {}
    counts = {'lidar': 0, 'imu': 0}
    oldest = {'lidar': 0., 'imu': 0.}
    regressions = {'lidar': 0, 'imu': 0}
    stable_since = None

    def receive(kind, raw):
        nonlocal stable_since
        if len(raw) < 12 or raw[:4] != b'\x00\x01\x00\x00':
            stable_since = None
            return
        sec, ns = struct.unpack_from('<iI', raw, 4)
        stamp = sec*10**9+ns
        if ns >= 10**9 or stamp <= 0:
            stable_since = None
            return
        previous = samples.get(kind)
        if previous and stamp <= previous[0]:
            regressions[kind] += 1
            stable_since = None
        samples[kind] = (stamp, time.monotonic())
        counts[kind] += 1
        oldest[kind] = max(oldest[kind], (node.get_clock().now().nanoseconds-stamp)/1e9)

    subscriptions = [node.create_subscription(typ, topic, lambda raw, k=kind: receive(k, raw),
        qos_profile_sensor_data, raw=True) for kind, typ, topic in
        [('lidar', CustomMsg, '/livox/lidar'), ('imu', Imu, '/livox/imu')]]
    started = time.monotonic()
    try:
        while time.monotonic()-started < timeout:
            rclpy.spin_once(node, timeout_sec=.02)
            now = node.get_clock().now().nanoseconds
            wall = time.monotonic()
            fresh = len(samples) == 2 and all(
                -.02 <= (now-stamp)/1e9 <= .2 and wall-receipt <= .2
                for stamp, receipt in samples.values())
            aligned = fresh and abs(samples['lidar'][0]-samples['imu'][0]) <= 200_000_000
            if not aligned:
                stable_since = None
                continue
            stable_since = wall if stable_since is None else stable_since
            if wall-stable_since >= hold:
                return {'ready': True, 'wait_s': wall-started, 'hold_s': hold,
                    'observed_counts': counts, 'startup_max_age_s': oldest,
                    'startup_regressions': regressions,
                    'final_source_age_s': {k: (now-v[0])/1e9 for k, v in samples.items()}}
        raise RuntimeError('LiDAR/IMU not fresh and aligned for a continuous second; FAST-LIO not started')
    finally:
        node.destroy_node()
        rclpy.shutdown(context=context)
