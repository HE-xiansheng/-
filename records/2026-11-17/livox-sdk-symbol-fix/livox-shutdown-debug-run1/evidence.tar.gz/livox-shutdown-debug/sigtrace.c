
#define _GNU_SOURCE
#include <execinfo.h>
#include <signal.h>
#include <unistd.h>
static void trace(int sig) {
  const char text[] = "NATIVE_SIGSEGV_BACKTRACE\n";
  write(STDERR_FILENO, text, sizeof(text)-1);
  void *frames[64];
  int n = backtrace(frames, 64);
  backtrace_symbols_fd(frames, n, STDERR_FILENO);
  signal(sig, SIG_DFL);
  raise(sig);
}
__attribute__((constructor)) static void setup(void) {
  void *frame[1]; backtrace(frame, 1);
  struct sigaction action = {0};
  action.sa_handler = trace;
  sigemptyset(&action.sa_mask);
  sigaction(SIGSEGV, &action, 0);
}
