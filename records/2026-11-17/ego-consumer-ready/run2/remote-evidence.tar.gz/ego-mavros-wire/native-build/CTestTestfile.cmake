# CMake generated Testfile for 
# Source directory: /tmp/ego-mavros-wire/native
# Build directory: /tmp/ego-mavros-wire/native-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
