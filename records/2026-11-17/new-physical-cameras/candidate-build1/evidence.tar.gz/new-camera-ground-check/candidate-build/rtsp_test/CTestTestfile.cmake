# CMake generated Testfile for 
# Source directory: /tmp/new-camera-ground-check/candidate-mpp/src/rtsp_test
# Build directory: /tmp/new-camera-ground-check/candidate-build/rtsp_test
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
