# CMake generated Testfile for 
# Source directory: /tmp/new-camera-ground-check/observer-src
# Build directory: /tmp/new-camera-ground-check/observer-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
