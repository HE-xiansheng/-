# CMake generated Testfile for 
# Source directory: /tmp/aruco-mavros-wire/candidate-src
# Build directory: /tmp/aruco-mavros-wire/candidate-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(landing_task "/tmp/aruco-mavros-wire/candidate-build/landing_task_test")
set_tests_properties(landing_task PROPERTIES  _BACKTRACE_TRIPLES "/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;28;add_test;/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;0;")
add_test(mode_start_gate "/tmp/aruco-mavros-wire/candidate-build/mode_start_gate_test")
set_tests_properties(mode_start_gate PROPERTIES  _BACKTRACE_TRIPLES "/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;28;add_test;/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;0;")
add_test(motion_limits "/tmp/aruco-mavros-wire/candidate-build/motion_limits_test")
set_tests_properties(motion_limits PROPERTIES  _BACKTRACE_TRIPLES "/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;28;add_test;/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;0;")
add_test(takeoff_replay "/tmp/aruco-mavros-wire/candidate-build/takeoff_replay_test" "/tmp/aruco-mavros-wire/candidate-src/test/data/takeoff_hover_20261027.csv")
set_tests_properties(takeoff_replay PROPERTIES  _BACKTRACE_TRIPLES "/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;26;add_test;/tmp/aruco-mavros-wire/candidate-src/CMakeLists.txt;0;")
