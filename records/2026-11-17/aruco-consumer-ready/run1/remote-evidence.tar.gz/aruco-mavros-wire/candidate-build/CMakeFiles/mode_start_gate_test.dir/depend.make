# Empty dependencies file for mode_start_gate_test.
# This may be replaced when dependencies are built.
