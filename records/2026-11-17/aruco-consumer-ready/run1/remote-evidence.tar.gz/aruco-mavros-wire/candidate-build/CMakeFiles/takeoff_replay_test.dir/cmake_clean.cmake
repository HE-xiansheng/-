file(REMOVE_RECURSE
  "CMakeFiles/takeoff_replay_test.dir/test/takeoff_replay_test.cpp.o"
  "CMakeFiles/takeoff_replay_test.dir/test/takeoff_replay_test.cpp.o.d"
  "takeoff_replay_test"
  "takeoff_replay_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/takeoff_replay_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
