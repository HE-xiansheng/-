# Empty dependencies file for Safina_land_test.
# This may be replaced when dependencies are built.
