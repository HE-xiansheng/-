file(REMOVE_RECURSE
  "CMakeFiles/motion_limits_test.dir/test/motion_limits_test.cpp.o"
  "CMakeFiles/motion_limits_test.dir/test/motion_limits_test.cpp.o.d"
  "motion_limits_test"
  "motion_limits_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/motion_limits_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
