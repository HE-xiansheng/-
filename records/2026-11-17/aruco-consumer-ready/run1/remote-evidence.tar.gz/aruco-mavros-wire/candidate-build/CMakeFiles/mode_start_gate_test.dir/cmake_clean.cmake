file(REMOVE_RECURSE
  "CMakeFiles/mode_start_gate_test.dir/test/mode_start_gate_test.cpp.o"
  "CMakeFiles/mode_start_gate_test.dir/test/mode_start_gate_test.cpp.o.d"
  "mode_start_gate_test"
  "mode_start_gate_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/mode_start_gate_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
