
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/tmp/aruco-mavros-wire/candidate-src/include/gcu/gcu_control.c" "CMakeFiles/Safina_land_test.dir/include/gcu/gcu_control.c.o" "gcc" "CMakeFiles/Safina_land_test.dir/include/gcu/gcu_control.c.o.d"
  "/tmp/aruco-mavros-wire/candidate-src/src/Safina_land_test.cpp" "CMakeFiles/Safina_land_test.dir/src/Safina_land_test.cpp.o" "gcc" "CMakeFiles/Safina_land_test.dir/src/Safina_land_test.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
