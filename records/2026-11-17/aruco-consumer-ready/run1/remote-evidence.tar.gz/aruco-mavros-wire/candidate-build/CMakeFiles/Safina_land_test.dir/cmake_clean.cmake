file(REMOVE_RECURSE
  "CMakeFiles/Safina_land_test.dir/include/gcu/gcu_control.c.o"
  "CMakeFiles/Safina_land_test.dir/include/gcu/gcu_control.c.o.d"
  "CMakeFiles/Safina_land_test.dir/src/Safina_land_test.cpp.o"
  "CMakeFiles/Safina_land_test.dir/src/Safina_land_test.cpp.o.d"
  "Safina_land_test"
  "Safina_land_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C CXX)
  include(CMakeFiles/Safina_land_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
