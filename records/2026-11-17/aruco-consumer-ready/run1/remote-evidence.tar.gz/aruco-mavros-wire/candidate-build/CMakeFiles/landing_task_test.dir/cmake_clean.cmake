file(REMOVE_RECURSE
  "CMakeFiles/landing_task_test.dir/test/landing_task_test.cpp.o"
  "CMakeFiles/landing_task_test.dir/test/landing_task_test.cpp.o.d"
  "landing_task_test"
  "landing_task_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/landing_task_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
