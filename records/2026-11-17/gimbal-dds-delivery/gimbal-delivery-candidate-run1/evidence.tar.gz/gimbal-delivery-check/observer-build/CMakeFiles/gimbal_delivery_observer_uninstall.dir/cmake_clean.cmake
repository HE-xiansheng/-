file(REMOVE_RECURSE
  "CMakeFiles/gimbal_delivery_observer_uninstall"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/gimbal_delivery_observer_uninstall.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
