file(REMOVE_RECURSE
  "CMakeFiles/rtsp_hw_pub_ultra.dir/src/rtsp_hw_pub_ultra.cpp.o"
  "CMakeFiles/rtsp_hw_pub_ultra.dir/src/rtsp_hw_pub_ultra.cpp.o.d"
  "rtsp_hw_pub_ultra"
  "rtsp_hw_pub_ultra.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/rtsp_hw_pub_ultra.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
