# Empty dependencies file for frame_rate_gate_test.
# This may be replaced when dependencies are built.
