# Empty compiler generated dependencies file for rtsp_hw_pub_ultra.
# This may be replaced when dependencies are built.
