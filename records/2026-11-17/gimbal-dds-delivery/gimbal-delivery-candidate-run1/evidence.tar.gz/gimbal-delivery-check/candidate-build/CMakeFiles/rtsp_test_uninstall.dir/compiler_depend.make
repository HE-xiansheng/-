# Empty custom commands generated dependencies file for rtsp_test_uninstall.
# This may be replaced when dependencies are built.
