file(REMOVE_RECURSE
  "CMakeFiles/frame_rate_gate_test.dir/test/frame_rate_gate_test.cpp.o"
  "CMakeFiles/frame_rate_gate_test.dir/test/frame_rate_gate_test.cpp.o.d"
  "frame_rate_gate_test"
  "frame_rate_gate_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/frame_rate_gate_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
