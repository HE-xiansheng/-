# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for rtsp_hw_pub_ultra.
