#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_datatypes.h>
#include <Eigen/Dense>
#include <deque>
#include <string>
#include <cmath>
#include <chrono>
#include <stdexcept>

class VisionToMavros {
public:
    VisionToMavros(ros::NodeHandle& nh, ros::NodeHandle& pnh)
        : init_vision_flag_(false),vcnt(0)
    {
        // 参数
        double publish_rate;
        std::string vision_pose_topic;
        pnh.param<double>("publish_rate", publish_rate, 30.0);
        pnh.param<std::string>("vision_pose_topic",vision_pose_topic,std::string("/Odometry"));

        // 时间戳必须来自测量；定时器仅限频，不能把缓存位姿伪装成新观测。
        pnh.param<double>("max_source_age", max_source_age_, 0.2);
        pnh.param<double>("future_tolerance", future_tolerance_, 0.02);
        if (!std::isfinite(publish_rate) || publish_rate <= 0.0 ||
            !std::isfinite(max_source_age_) || max_source_age_ <= 0.0 ||
            !std::isfinite(future_tolerance_) || future_tolerance_ < 0.0)
            throw std::runtime_error("invalid relay timing parameters");

        //  body -> lidar
        double body_lidar_x, body_lidar_y, body_lidar_z;
        pnh.param<double>("body_lidar_x", body_lidar_x, 0.0); 
        pnh.param<double>("body_lidar_y", body_lidar_y, 0.0);
        pnh.param<double>("body_lidar_z", body_lidar_z, 0.0);
        t_body_lidar_ = Eigen::Vector3d(body_lidar_x, body_lidar_y, body_lidar_z);

        p_vision_body_.setZero();
        q_vision_body_.getIdentity();

        // 订阅与发布
        vision_sub_ = pnh.subscribe(vision_pose_topic, 1, &VisionToMavros::visionCallback, this);
        vision_pub_ = pnh.advertise<geometry_msgs::PoseStamped>("/mavros/vision_pose/pose", 10);

        // 定时器
        timer_ = nh.createTimer(ros::Duration(1.0 / publish_rate),&VisionToMavros::publishVisionPose, this);

        // ROS_INFO("FastLIO to MAVROS converter initialized");
        // ROS_INFO("Window size: %d, Publish rate: %.2f Hz", window_size, publish_rate);
    }

private:

    void visionCallback(const nav_msgs::Odometry::ConstPtr& msg) {
        const ros::Time now = ros::Time::now();
        const double age = (now - msg->header.stamp).toSec();
        const auto &p = msg->pose.pose.position;
        const auto &q = msg->pose.pose.orientation;
        const double norm2 = q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w;
        if (msg->header.stamp.isZero() || age < -future_tolerance_ || age > max_source_age_ ||
            (!source_stamp_.isZero() && msg->header.stamp <= source_stamp_) ||
            msg->header.frame_id != "camera_init" || msg->child_frame_id != "body" ||
            !std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z) ||
            !std::isfinite(norm2) || norm2 < 0.81 || norm2 > 1.21) {
            ROS_WARN_THROTTLE(2.0, "拒绝无效/重复/乱序/过期定位观测；保留最后有效测量时间");
            return;
        }
        source_stamp_ = msg->header.stamp;
        source_received_ = std::chrono::steady_clock::now();

        // 1. 先把 FastLIO 的输出当成“雷达在 map 下”的位姿读进来
        Eigen::Vector3d p_lidar;
        p_lidar(0) = msg->pose.pose.position.x;
        p_lidar(1) = msg->pose.pose.position.y;
        p_lidar(2) = msg->pose.pose.position.z;

        q_vision_body_.setX(msg->pose.pose.orientation.x);
        q_vision_body_.setY(msg->pose.pose.orientation.y);
        q_vision_body_.setZ(msg->pose.pose.orientation.z);
        q_vision_body_.setW(msg->pose.pose.orientation.w);

        // 2. 由雷达姿态算旋转矩阵 R_map_lidar
        tf::Matrix3x3 R_tf(q_vision_body_);
        Eigen::Matrix3d R_map_lidar;
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                R_map_lidar(i,j) = R_tf[i][j];



        // 4. 计算机体在 map 下的位置：p_body = p_lidar - R * (0.05, 0, 0)
        Eigen::Vector3d p_body = p_lidar - R_map_lidar * t_body_lidar_;

        // 5. 把“机体位置”存入 p_vision_body_，后面所有代码都当成机体用
        p_vision_body_ = p_body;

        // 6. 机体当前欧拉角（用雷达四元数表示，两者平行安装就一样）
        double cur_r, cur_p, cur_y;
        tf::Matrix3x3(q_vision_body_).getRPY(cur_r, cur_p, cur_y);

        // 7. 初始化阶段：对“机体位姿”做前 100 帧平均，作为零点
        if (!init_vision_flag_) {
            p_vision_delta_ += p_vision_body_;
            rpy_delta_(0)   += cur_r;
            rpy_delta_(1)   += cur_p;
            rpy_delta_(2)   += cur_y;

            vcnt++;
            if (vcnt >= 100) {
                p_vision_delta_ /= 100.0;
                rpy_delta_      /= 100.0;
                init_vision_flag_ = true;
            }
        }
    }

    void publishVisionPose(const ros::TimerEvent&) {
        if (!init_vision_flag_ || source_stamp_.isZero() || source_stamp_ <= published_stamp_) return;
        const double age = (ros::Time::now() - source_stamp_).toSec();
        const double received_age = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - source_received_).count();
        if (age < -future_tolerance_ || age > max_source_age_ || received_age > max_source_age_) {
            ROS_WARN_THROTTLE(2.0, "定位观测在发布前过期，停止输出缓存位姿");
            return;
        }

        //1.发布map下的位姿
        geometry_msgs::PoseStamped vision_msg;
        vision_msg.header.stamp = source_stamp_;
        vision_msg.header.frame_id = "map";
        //位置消除偏差
        Eigen::Vector3d p_map_ = p_vision_body_-p_vision_delta_;

        vision_msg.pose.position.x = p_map_(0);
        vision_msg.pose.position.y = p_map_(1);
        vision_msg.pose.position.z = p_map_(2);        

        // 姿态消除误差
        double cur_r, cur_p, cur_y;
        tf::Matrix3x3(q_vision_body_).getRPY(cur_r, cur_p, cur_y);
        cur_r -= rpy_delta_(0);
        cur_p -= rpy_delta_(1);
        cur_y -= rpy_delta_(2);

        tf::Quaternion q_map_;
        q_map_.setRPY(cur_r, cur_p, cur_y);

        vision_msg.pose.orientation.x = q_map_.x();
        vision_msg.pose.orientation.y = q_map_.y();
        vision_msg.pose.orientation.z = q_map_.z();
        vision_msg.pose.orientation.w = q_map_.w();

        vision_pub_.publish(vision_msg);
        published_stamp_ = source_stamp_;


        ROS_INFO_THROTTLE(2.0, "\nposition in map_:\n   x: %.6f\n   y: %.6f\n   z: %.6f\norientation of body:\n   x: %.6f\n   y: %.6f\n   z: %.6f\n   w: %.6f", \
            p_map_[0],p_map_[1],p_map_(2),q_map_.x(),q_map_.y(),q_map_.z(),q_map_.w());


    }

private:
    // 单线程回调：每个严格递增源戳最多发布一次；源重启/时钟倒退需地面重启转发。
    ros::Time source_stamp_, published_stamp_;
    std::chrono::steady_clock::time_point source_received_;
    double max_source_age_ = 0.2, future_tolerance_ = 0.02;
    ros::Subscriber vision_sub_;
    ros::Publisher vision_pub_;
    ros::Timer timer_;

    Eigen::Vector3d p_vision_body_;
    tf::Quaternion q_vision_body_;

    bool init_vision_flag_;
    int vcnt;
    Eigen::Vector3d p_vision_delta_{0,0,0};
    Eigen::Vector3d rpy_delta_{0,0,0};

    Eigen::Vector3d t_body_lidar_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "vision_to_mavros");
    ros::NodeHandle nh;
    ros::NodeHandle pnh("~");

    VisionToMavros converter(nh, pnh);
    ros::spin();    
    return 0;
}
