# CMake generated Testfile for 
# Source directory: /tmp/mpp-reconnect-check/candidate-src
# Build directory: /tmp/mpp-reconnect-check/candidate-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(frame_rate_gate_jitter "/tmp/mpp-reconnect-check/candidate-build/frame_rate_gate_test")
set_tests_properties(frame_rate_gate_jitter PROPERTIES  _BACKTRACE_TRIPLES "/tmp/mpp-reconnect-check/candidate-src/CMakeLists.txt;25;add_test;/tmp/mpp-reconnect-check/candidate-src/CMakeLists.txt;0;")
