# CMake generated Testfile for 
# Source directory: /tmp/mpp-reconnect-check/observer-src
# Build directory: /tmp/mpp-reconnect-check/observer-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
