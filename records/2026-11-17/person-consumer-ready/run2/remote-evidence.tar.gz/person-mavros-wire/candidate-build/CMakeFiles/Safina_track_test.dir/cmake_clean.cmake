file(REMOVE_RECURSE
  "CMakeFiles/Safina_track_test.dir/src/Safina_track_test.cpp.o"
  "CMakeFiles/Safina_track_test.dir/src/Safina_track_test.cpp.o.d"
  "Safina_track_test"
  "Safina_track_test.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Safina_track_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
