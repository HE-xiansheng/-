# Empty compiler generated dependencies file for Safina_track_test.
# This may be replaced when dependencies are built.
