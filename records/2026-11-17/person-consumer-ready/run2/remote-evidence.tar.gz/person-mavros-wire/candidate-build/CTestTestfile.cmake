# CMake generated Testfile for 
# Source directory: /tmp/person-mavros-wire/candidate-src
# Build directory: /tmp/person-mavros-wire/candidate-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
