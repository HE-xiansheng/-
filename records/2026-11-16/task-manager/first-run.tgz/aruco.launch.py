from launch import LaunchDescription
from launch_ros.actions import Node
def generate_launch_description():
    return LaunchDescription([Node(package='aruco_test', executable='Safina_aruco_test', output="screen", parameters=['/home/orangepi/drone_platform/01_apps/mission_demo/workspace/install/aruco_test/share/aruco_test/config/aruco.yaml'], remappings=[]),
        Node(package='land_test', executable='Safina_land_test', output="screen", parameters=['/home/orangepi/drone_platform/01_apps/mission_demo/workspace/install/land_test/share/land_test/config/takeoff_land.yaml', {'gimbal_down_on_startup': True}], remappings=[])])
