from launch import LaunchDescription
from launch_ros.actions import Node
def generate_launch_description():
    return LaunchDescription([Node(package='yolo_ultra_test', executable='Safina_yoloUltra_test', output="screen", parameters=['/home/orangepi/drone_platform/01_apps/mission_demo/workspace/install/yolo_ultra_test/share/yolo_ultra_test/config/yolo_track.yaml'], remappings=[]),
        Node(package='track_test', executable='Safina_track_test', output="screen", parameters=['/home/orangepi/drone_platform/01_apps/mission_demo/workspace/install/track_test/share/track_test/config/track.yaml'], remappings=[])])
