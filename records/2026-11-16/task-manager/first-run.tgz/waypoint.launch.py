from launch import LaunchDescription
from launch_ros.actions import Node
def generate_launch_description():
    return LaunchDescription([Node(package='waypoint_mission', executable='waypoint_mission', output="screen", parameters=[{'mission_file': '/home/orangepi/drone_platform/01_apps/mission_demo/workspace/src/waypoint_mission/missions/abc_photo.yaml', 'dry_run': False, 'bench_mode': False}], remappings=[('/Odometry', '/factory_fastlio/odometry')]),
        Node(package='waypoint_mission', executable='waypoint_photo', output="screen", parameters=[{'image_topic': '/rtsp_cam/image_color'}], remappings=[])])
