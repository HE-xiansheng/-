from launch import LaunchDescription
from launch_ros.actions import Node
def generate_launch_description():
    return LaunchDescription([Node(package='rtsp_test', executable='rtsp_hw_pub_ultra', output="screen", parameters=[], remappings=[]),
        Node(package='waypoint_mission', executable='waypoint_mission', output="screen", parameters=[{'mission_file': '/tmp/task-manager-validation/store/runs/20261116-204009-e3850b7c/mission.yaml', 'dry_run': False, 'bench_mode': False}], remappings=[('/Odometry', '/factory_fastlio/odometry')]),
        Node(package='waypoint_mission', executable='waypoint_photo', output="screen", parameters=[{'image_topic': '/rtsp_cam/image_color'}], remappings=[])])
