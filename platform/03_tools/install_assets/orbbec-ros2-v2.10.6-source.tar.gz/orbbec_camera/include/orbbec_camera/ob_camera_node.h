/*******************************************************************************
 * Copyright (c) 2023 Orbbec 3D Technology, Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *******************************************************************************/

#pragma once

#include <nlohmann/json.hpp>

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <queue>
#include <rclcpp/rclcpp.hpp>
#include <string>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include <atomic>
#include <opencv2/opencv.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/point_cloud2_iterator.hpp>
#include <std_srvs/srv/set_bool.hpp>
#include <std_srvs/srv/empty.hpp>
#include <diagnostic_updater/diagnostic_updater.hpp>
#include <std_msgs/msg/int32.hpp>

#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/compressed_image.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <camera_info_manager/camera_info_manager.hpp>

#include <image_publisher/image_publisher.hpp>
#include <image_transport/publisher.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include "libobsensor/ObSensor.hpp"

#include "orbbec_camera_msgs/msg/device_info.hpp"
#include "orbbec_camera_msgs/msg/device_status.hpp"
#include "orbbec_camera_msgs/msg/depth_filter_state.hpp"
#include "orbbec_camera_msgs/msg/depth_filters_status.hpp"
#include "orbbec_camera_msgs/srv/get_device_config.hpp"
#include "orbbec_camera_msgs/srv/get_action_config.hpp"
#include "orbbec_camera_msgs/srv/get_device_info.hpp"
#include "orbbec_camera_msgs/srv/get_awb_gain.hpp"
#include "orbbec_camera_msgs/msg/extrinsics.hpp"
#include "orbbec_camera_msgs/msg/metadata.hpp"
#include "orbbec_camera_msgs/msg/imu_info.hpp"
#include "orbbec_camera_msgs/srv/get_int32.hpp"
#include "orbbec_camera_msgs/srv/get_string.hpp"
#include "orbbec_camera_msgs/srv/set_int32.hpp"
#include "orbbec_camera_msgs/srv/set_awb_gain.hpp"
#include "orbbec_camera_msgs/srv/get_bool.hpp"
#include "orbbec_camera_msgs/srv/set_string.hpp"
#include "orbbec_camera_msgs/srv/set_filter.hpp"
#include "orbbec_camera_msgs/srv/set_action_config.hpp"
#include "orbbec_camera_msgs/srv/set_arrays.hpp"
#include "orbbec_camera_msgs/srv/set_stream_profile.hpp"
#include "orbbec_camera_msgs/srv/get_user_calib_params.hpp"
#include "orbbec_camera_msgs/srv/set_user_calib_params.hpp"
#include "orbbec_camera/constants.h"
#include "orbbec_camera/dynamic_params.h"
#include "orbbec_camera/d2c_viewer.h"
#include "orbbec_camera/image_publisher.h"
#include "orbbec_camera/fps_counter.hpp"
#include "orbbec_camera/stream_status.hpp"
#include "orbbec_camera/timestamp_csv_logger.h"
#include "jpeg_decoder.h"
#include <std_msgs/msg/header.hpp>
#include <fcntl.h>
#include <unistd.h>

#if __has_include(<tf2/LinearMath/Quaternion.hpp>)
#include <tf2/LinearMath/Quaternion.hpp>
#include <tf2/LinearMath/Vector3.hpp>
#elif __has_include(<tf2/LinearMath/Quaternion.h>)
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Vector3.h>
#else
#error "No compatible tf2 LinearMath headers found"
#endif

#if __has_include(<tf2_ros/static_transform_broadcaster.hpp>)
#include <tf2_ros/static_transform_broadcaster.hpp>
#include <tf2_ros/transform_broadcaster.hpp>
#elif __has_include(<tf2_ros/static_transform_broadcaster.h>)
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2_ros/transform_broadcaster.h>
#else
#error "No compatible tf2_ros broadcaster headers found"
#endif

#if __has_include(<cv_bridge/cv_bridge.hpp>)
#include <cv_bridge/cv_bridge.hpp>
#elif __has_include(<cv_bridge/cv_bridge.h>)
#include <cv_bridge/cv_bridge.h>
#endif

#define STREAM_NAME(sip)                                                                       \
  (static_cast<std::ostringstream&&>(std::ostringstream()                                      \
                                     << _stream_name[sip.first]                                \
                                     << ((sip.second > 0) ? std::to_string(sip.second) : ""))) \
      .str()
#define FRAME_ID(sip)                                                                              \
  (static_cast<std::ostringstream&&>(std::ostringstream()                                          \
                                     << getNamespaceStr() << "_" << STREAM_NAME(sip) << "_frame")) \
      .str()
#define OPTICAL_FRAME_ID(sip)                                                                     \
  (static_cast<std::ostringstream&&>(                                                             \
       std::ostringstream() << getNamespaceStr() << "_" << STREAM_NAME(sip) << "_optical_frame")) \
      .str()
#define ALIGNED_DEPTH_TO_FRAME_ID(sip)                                            \
  (static_cast<std::ostringstream&&>(std::ostringstream()                         \
                                     << getNamespaceStr() << "_aligned_depth_to_" \
                                     << STREAM_NAME(sip) << "_frame"))            \
      .str()
#define BASE_FRAME_ID() \
  (static_cast<std::ostringstream&&>(std::ostringstream() << getNamespaceStr() << "_link")).str()
#define ODOM_FRAME_ID()                                                                           \
  (static_cast<std::ostringstream&&>(std::ostringstream() << getNamespaceStr() << "_odom_frame")) \
      .str()

#define DEVICE_PATH "/dev/camsync"

namespace orbbec_camera {
class StreamConfigurationError : public std::runtime_error {
 public:
  explicit StreamConfigurationError(const std::string& message) : std::runtime_error(message) {}
};

using GetDeviceConfig = orbbec_camera_msgs::srv::GetDeviceConfig;
using GetActionConfig = orbbec_camera_msgs::srv::GetActionConfig;
using GetDeviceInfo = orbbec_camera_msgs::srv::GetDeviceInfo;
using Extrinsics = orbbec_camera_msgs::msg::Extrinsics;
using SetInt32 = orbbec_camera_msgs::srv::SetInt32;
using GetInt32 = orbbec_camera_msgs::srv::GetInt32;
using GetAwbGain = orbbec_camera_msgs::srv::GetAwbGain;
using SetAwbGain = orbbec_camera_msgs::srv::SetAwbGain;
using GetString = orbbec_camera_msgs::srv::GetString;
using SetString = orbbec_camera_msgs::srv::SetString;
using SetBool = std_srvs::srv::SetBool;
using GetBool = orbbec_camera_msgs::srv::GetBool;
using SetFilter = orbbec_camera_msgs::srv::SetFilter;
using SetActionConfig = orbbec_camera_msgs::srv::SetActionConfig;
using SetArrays = orbbec_camera_msgs::srv::SetArrays;
using SetStreamProfile = orbbec_camera_msgs::srv::SetStreamProfile;
using SetUserCalibParams = orbbec_camera_msgs::srv::SetUserCalibParams;
using GetUserCalibParams = orbbec_camera_msgs::srv::GetUserCalibParams;
using DepthFilterState = orbbec_camera_msgs::msg::DepthFilterState;
using DepthFiltersStatus = orbbec_camera_msgs::msg::DepthFiltersStatus;

typedef std::pair<ob_stream_type, int> stream_index_pair;

const stream_index_pair COLOR{OB_STREAM_COLOR, 0};
const stream_index_pair COLOR_LEFT{OB_STREAM_COLOR_LEFT, 0};
const stream_index_pair COLOR_RIGHT{OB_STREAM_COLOR_RIGHT, 0};
const stream_index_pair DEPTH{OB_STREAM_DEPTH, 0};
const stream_index_pair INFRA0{OB_STREAM_IR, 0};
const stream_index_pair INFRA1{OB_STREAM_IR_LEFT, 0};
const stream_index_pair INFRA2{OB_STREAM_IR_RIGHT, 0};
const stream_index_pair LIDAR{OB_STREAM_LIDAR, 0};

const stream_index_pair GYRO{OB_STREAM_GYRO, 0};
const stream_index_pair ACCEL{OB_STREAM_ACCEL, 0};

const std::vector<stream_index_pair> IMAGE_STREAMS = {COLOR,  COLOR_LEFT, COLOR_RIGHT, DEPTH,
                                                      INFRA0, INFRA1,     INFRA2,      LIDAR};

const std::vector<stream_index_pair> HID_STREAMS = {GYRO, ACCEL};

const std::map<OBStreamType, OBFrameType> STREAM_TYPE_TO_FRAME_TYPE = {
    {OB_STREAM_COLOR, OB_FRAME_COLOR},
    {OB_STREAM_COLOR_LEFT, OB_FRAME_COLOR_LEFT},
    {OB_STREAM_COLOR_RIGHT, OB_FRAME_COLOR_RIGHT},
    {OB_STREAM_DEPTH, OB_FRAME_DEPTH},
    {OB_STREAM_IR, OB_FRAME_IR},
    {OB_STREAM_IR_LEFT, OB_FRAME_IR_LEFT},
    {OB_STREAM_IR_RIGHT, OB_FRAME_IR_RIGHT},
    {OB_STREAM_GYRO, OB_FRAME_GYRO},
    {OB_STREAM_ACCEL, OB_FRAME_ACCEL},
};

typedef struct {
  uint8_t mode;
  uint16_t fps;
} cs_param_t;

class OBCameraNode {
 public:
  OBCameraNode(rclcpp::Node* node, std::shared_ptr<ob::Device> device,
               std::shared_ptr<Parameters> parameters, bool use_intra_process = false,
               bool is_playback_device = false);

  template <class T>
  void setAndGetNodeParameter(
      T& param, const std::string& param_name, const T& default_value,
      const rcl_interfaces::msg::ParameterDescriptor& parameter_descriptor =
          rcl_interfaces::msg::ParameterDescriptor());  // set and get parameter

  ~OBCameraNode() noexcept;

  void clean() noexcept;

  // Safely expose the lock
  template <typename Func>
  auto withDeviceLock(Func&& func) -> decltype(func()) {
    std::lock_guard<std::recursive_mutex> lock(device_lock_);
    return func();
  }

  void rebootDevice();

  void startStreams();

  void startIMUSyncStream();

  void startIMU();

  void restartPlaybackStreams();

  int openSocSyncPwmTrigger(uint16_t fps);
  int closeSocSyncPwmTrigger();
  void startGmslTrigger();
  void stopGmslTrigger();

  bool isParamCalibrated() const {
    return (color_info_manager_ && color_info_manager_->isCalibrated() && ir_info_manager_ &&
            ir_info_manager_->isCalibrated());
  }
  void fillStreamStatus(orbbec_camera_msgs::msg::DeviceStatus& status_msg);

  bool checkUserCalibrationReady() {
    static bool first_check = true;
    if (first_check) {
      first_check = false;
      std::string data_read;
      if (readCustomerData(data_read)) {
        user_calibration_ready_ = true;
      } else {
        user_calibration_ready_ = false;
      }
    }
    return user_calibration_ready_;
  }

 private:
  struct IMUData {
    IMUData() = default;
    IMUData(stream_index_pair stream, Eigen::Vector3d data, double timestamp)
        : stream_(std::move(stream)), data_(std::move(data)), timestamp_(timestamp) {}
    [[nodiscard]] bool isSet() const { return timestamp_ >= 0; }
    stream_index_pair stream_{};
    Eigen::Vector3d data_{};
    double timestamp_ = -1;  // in nanoseconds
  };

  struct PendingStreamProfile {
    stream_index_pair stream_index;
    int requested_width = 0;
    int requested_height = 0;
    int requested_fps = 0;
    std::shared_ptr<ob::VideoStreamProfile> profile;
  };

  void setupDevices();

  void loadConfigJson();

  void captureInitialRosParameters();

  bool isLaunchParamProvided(const std::string& param_name) const;

  bool exportConfigJsonToFile(const std::string& file_path, std::string& message);

  void exportConfigJsonIfRequested();

  bool isConfigJsonLoaded() const;

  void syncConfigJsonApplicationConfig();

  void syncApplicationSensorConfigForExport();

  void syncApplicationPointCloudConfigForExport();

  void syncApplicationHdrMergeConfigForExport();

  void syncConfigJsonDeviceSettings();

  void syncConfigJsonFilterSettings(const std::vector<std::shared_ptr<ob::Filter>>& filters,
                                    const std::string& sensor_name);

  void setupProfiles();

  bool validate301SeriesStreamFrameRates(const std::map<stream_index_pair, int>& fps,
                                         std::string& message) const;

  std::shared_ptr<ob::VideoStreamProfile> selectVideoStreamProfile(
      const stream_index_pair& stream_index, int width, int height, int fps, OBFormat format);

  std::optional<stream_index_pair> getImageStreamByName(const std::string& stream_name) const;

  bool validateStreamProfileRequest(const std::shared_ptr<SetStreamProfile::Request>& request,
                                    std::vector<PendingStreamProfile>& pending_profiles,
                                    std::string& message);

  bool applyStreamProfiles(const std::vector<PendingStreamProfile>& pending_profiles,
                           std::string& message);

  void clearColorFrameQueues();

  void stopColorFrameThreads();

  void setupImageBuffers();

  void updateImageConfig(const stream_index_pair& stream_index);

  void printSensorProfiles(const std::shared_ptr<ob::Sensor>& sensor);

  void selectBaseStream();

  void getParameters();

  void setupTopics();

  void setupImagePublisher(const stream_index_pair& stream_index);

  rmw_qos_profile_t getImageQosProfile(const stream_index_pair& stream_index) const;

  void setupPipelineConfig();

  void setupDiagnosticUpdater();

  void onTemperatureUpdate(diagnostic_updater::DiagnosticStatusWrapper& status);

  void setupCameraCtrlServices();

  void getColorQueueStatsCallback(const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                                  std::shared_ptr<std_srvs::srv::SetBool::Response>& response);

  void stopStreams();

  void stopIMU();

  void setupDefaultImageFormat();

  void setupPublishers();

  void registerStreamStatus(const std::string& topic_name,
                            StreamStatusTracker::SubscriberCountFn subscriber_count);
  void removeStreamStatus(const std::string& topic_name);
  void recordStreamStatus(const std::string& topic_name,
                          const builtin_interfaces::msg::Time& stamp);
  std::string resolveStreamStatusTopic(const std::string& topic_name) const;
  std::string compressedStreamStatusTopic(const stream_index_pair& stream_index) const;

  void syncSoftwareAlignment();

  void publishDepthFiltersStatus();

  void publishLrmObstacleDistance();

  DepthFilterState buildDepthFilterState(const std::string& filter_name, bool enabled,
                                         const std::shared_ptr<ob::Filter>& filter) const;
  DepthFilterState buildEnhancedDepthFilterState() const;

  static std::string normalizeDepthFilterName(const std::string& filter_name);

  static void appendDepthFilterParam(DepthFilterState& filter_state, const std::string& name,
                                     const std::string& value);

  void updateDepthFilterEnabledCache(const std::string& filter_name, bool enabled);

  bool applyNamedDepthFilterConfig(
      const std::string& filter_name, bool enabled,
      const std::vector<orbbec_camera_msgs::msg::DepthFilterParam>& params, std::string& message);
  bool applyEnhancedDepthFilterConfig(
      bool enabled, const std::vector<float>& positional_params,
      const std::vector<orbbec_camera_msgs::msg::DepthFilterParam>& named_params,
      std::string& message);
  bool validateEnhancedDepthFilterConfig(std::string& message) const;
  bool ensureEnhancedDepthFilter(std::string& message);
  void applyEnhancedDepthConfidenceThreshold();
  std::shared_ptr<ob::FrameSet> processEnhancedDepthFilter(
      const std::shared_ptr<ob::FrameSet>& frame_set);
  bool convertEnhancedDepthColorFrame(const std::shared_ptr<ob::FrameSet>& frame_set);
  void setupConfidencePublishers();
  void publishConfidenceFrame(const std::shared_ptr<ob::Frame>& confidence_frame);

  void setupCameraInfo();

  void publishStaticTF(const rclcpp::Time& t, const tf2::Vector3& trans, const tf2::Quaternion& q,
                       const std::string& from, const std::string& to);

  void calcAndPublishStaticTransform();

  void publishDynamicTransforms();

  void publishStaticTransforms();

  std::optional<OBCameraParam> findDefaultCameraParam();

  std::optional<OBCameraParam> getDepthCameraParam();

  std::optional<OBCameraParam> getColorCameraParam();

  void setStreamsEnableCallback(const std::shared_ptr<std_srvs::srv::SetBool::Request> request,
                                std::shared_ptr<std_srvs::srv::SetBool::Response> response);
  void setImageRegistrationModeCallback(const std::shared_ptr<SetString::Request> request,
                                        std::shared_ptr<SetString::Response> response);

  void getStreamsEnableCallback(
      const std::shared_ptr<orbbec_camera_msgs::srv::GetBool::Request> request,
      std::shared_ptr<orbbec_camera_msgs::srv::GetBool::Response> response);

  void getExposureCallback(const std::shared_ptr<GetInt32::Request>& request,
                           std::shared_ptr<GetInt32::Response>& response,
                           const stream_index_pair& stream_index);

  void setExposureCallback(const std::shared_ptr<SetInt32::Request>& request,
                           std::shared_ptr<SetInt32::Response>& response,
                           const stream_index_pair& stream_index);

  void getGainCallback(const std::shared_ptr<GetInt32::Request>& request,
                       std::shared_ptr<GetInt32::Response>& response,
                       const stream_index_pair& stream_index);

  void setGainCallback(const std::shared_ptr<SetInt32::Request>& request,
                       std::shared_ptr<SetInt32::Response>& response,
                       const stream_index_pair& stream_index);

  void getWhiteBalanceCallback(const std::shared_ptr<GetInt32::Request>& request,
                               std::shared_ptr<GetInt32::Response>& response);

  void setWhiteBalanceCallback(const std::shared_ptr<SetInt32 ::Request>& request,
                               std::shared_ptr<SetInt32 ::Response>& response);

  void getColorWbCtrlCallback(const std::shared_ptr<GetInt32::Request>& request,
                              std::shared_ptr<GetInt32::Response>& response);

  void setColorWbCtrlCallback(const std::shared_ptr<SetInt32::Request>& request,
                              std::shared_ptr<SetInt32::Response>& response);

  void getAutoWhiteBalanceCallback(const std::shared_ptr<GetInt32::Request>& request,
                                   std::shared_ptr<GetInt32::Response>& response);

  void setAutoWhiteBalanceCallback(const std::shared_ptr<SetBool::Request>& request,
                                   std::shared_ptr<SetBool::Response>& response);

  void getAeAwbStatusCallback(const std::shared_ptr<GetInt32::Request>& request,
                              std::shared_ptr<GetInt32::Response>& response);

  void getAwbGainCallback(const std::shared_ptr<GetAwbGain::Request>& request,
                          std::shared_ptr<GetAwbGain::Response>& response);

  void setAwbGainCallback(const std::shared_ptr<SetAwbGain::Request>& request,
                          std::shared_ptr<SetAwbGain::Response>& response);

  void setAutoExposureCallback(const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                               std::shared_ptr<std_srvs::srv::SetBool::Response>& response,
                               const stream_index_pair& stream_index);

  void setAeRoiCallback(const std::shared_ptr<SetArrays::Request>& request,
                        std::shared_ptr<SetArrays::Response>& response,
                        const stream_index_pair& stream_index);

  void setLaserEnableCallback(const std::shared_ptr<rmw_request_id_t>& request_header,
                              const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                              std::shared_ptr<std_srvs::srv::SetBool::Response>& response);

  void setFloodEnableCallback(const std::shared_ptr<rmw_request_id_t>& request_header,
                              const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                              std::shared_ptr<std_srvs::srv::SetBool::Response>& response);

  void setLdpEnableCallback(const std::shared_ptr<rmw_request_id_t>& request_header,
                            const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                            std::shared_ptr<std_srvs::srv::SetBool::Response>& response);

  void setPtpConfigCallback(const std::shared_ptr<rmw_request_id_t>& request_header,
                            const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                            std::shared_ptr<std_srvs::srv::SetBool::Response>& response);

  void setFanWorkModeCallback(const std::shared_ptr<SetInt32::Request>& request,
                              std::shared_ptr<SetInt32::Response>& response);

  void getDeviceInfoCallback(const std::shared_ptr<GetDeviceInfo::Request>& request,
                             std::shared_ptr<GetDeviceInfo::Response>& response);

  void getDeviceConfigCallback(const std::shared_ptr<GetDeviceConfig::Request>& request,
                               std::shared_ptr<GetDeviceConfig::Response>& response);

  void getActionConfigCallback(const std::shared_ptr<GetActionConfig::Request>& request,
                               std::shared_ptr<GetActionConfig::Response>& response);

  void setActionConfigCallback(const std::shared_ptr<SetActionConfig::Request>& request,
                               std::shared_ptr<SetActionConfig::Response>& response);

  void getSDKVersion(const std::shared_ptr<GetString::Request>& request,
                     std::shared_ptr<GetString::Response>& response);

  void toggleSensorCallback(const std::shared_ptr<SetBool::Request>& request,
                            std::shared_ptr<SetBool::Response>& response,
                            const stream_index_pair& stream_index);

  void setMirrorCallback(const std::shared_ptr<SetBool::Request>& request,
                         std::shared_ptr<SetBool::Response>& response,
                         const stream_index_pair& stream_index);

  void setFlipCallback(const std::shared_ptr<SetBool::Request>& request,
                       std::shared_ptr<SetBool::Response>& response,
                       const stream_index_pair& stream_index);

  void setRotationCallback(const std::shared_ptr<SetInt32::Request>& request,
                           std::shared_ptr<SetInt32::Response>& response,
                           const stream_index_pair& stream_index);
  void getLaserStatusCallback(const std::shared_ptr<GetBool::Request>& request,
                              std::shared_ptr<GetBool::Response>& response);
  void getLdpStatusCallback(const std::shared_ptr<GetBool::Request>& request,
                            std::shared_ptr<GetBool::Response>& response);
  void getPtpConfigCallback(const std::shared_ptr<GetBool::Request>& request,
                            std::shared_ptr<GetBool::Response>& response);
  void getLrmMeasureDistanceCallback(const std::shared_ptr<GetInt32::Request>& request,
                                     std::shared_ptr<GetInt32::Response>& response);

  void setRESETTimestampCallback(const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                                 std::shared_ptr<std_srvs::srv::SetBool::Response>& response);
  void setSYNCInterleaveLaserCallback(const std::shared_ptr<SetInt32 ::Request>& request,
                                      std::shared_ptr<SetInt32 ::Response>& response);
  void setFilterCallback(const std::shared_ptr<SetFilter ::Request>& request,
                         std::shared_ptr<SetFilter ::Response>& response);
  void setPointCloudDecimationCallback(const std::shared_ptr<SetInt32::Request>& request,
                                       std::shared_ptr<SetInt32::Response>& response);
  void getPointCloudDecimationCallback(const std::shared_ptr<GetInt32::Request>& request,
                                       std::shared_ptr<GetInt32::Response>& response);
  void setDisparityRangeModeCallback(const std::shared_ptr<SetInt32::Request>& request,
                                     std::shared_ptr<SetInt32::Response>& response);
  void setDisparitySearchOffsetCallback(const std::shared_ptr<SetInt32::Request>& request,
                                        std::shared_ptr<SetInt32::Response>& response);
  void setSyncIoVoltageLevelCallback(const std::shared_ptr<SetInt32::Request>& request,
                                     std::shared_ptr<SetInt32::Response>& response);
  void setSYNCHostimeCallback(const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                              std::shared_ptr<std_srvs::srv::SetBool::Response>& response);
  void sendSoftwareTriggerCallback(const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                                   std::shared_ptr<std_srvs::srv::SetBool::Response>& response);

  bool toggleSensor(const stream_index_pair& stream_index, bool enabled, std::string& msg);

  void saveImageCallback(const std::shared_ptr<std_srvs::srv::Empty::Request>& request,
                         std::shared_ptr<std_srvs::srv::Empty::Response>& response);

  void savePointCloudCallback(const std::shared_ptr<std_srvs::srv::Empty::Request>& request,
                              std::shared_ptr<std_srvs::srv::Empty::Response>& response);

  void switchIRCameraCallback(const std::shared_ptr<SetString::Request>& request,
                              std::shared_ptr<SetString::Response>& response);

  void exportConfigJsonCallback(const std::shared_ptr<SetString::Request>& request,
                                std::shared_ptr<SetString::Response>& response);

  bool writeCustomerData(const std::string& data);

  bool readCustomerData(std::string& out_data);

  void writeCustomerDataCallback(const std::shared_ptr<SetString::Request>& request,
                                 std::shared_ptr<SetString::Response>& response);

  void readCustomerDataCallback(const std::shared_ptr<GetString::Request>& request,
                                std::shared_ptr<GetString::Response>& response);

  void getUserCalibParamsCallback(const std::shared_ptr<GetUserCalibParams::Request>& request,
                                  std::shared_ptr<GetUserCalibParams::Response>& response);

  void setAEReferenceStreamCallback(const std::shared_ptr<SetString::Request>& request,
                                    std::shared_ptr<SetString::Response>& response);

  void setAEStrategyCallback(const std::shared_ptr<SetString::Request>& request,
                             std::shared_ptr<SetString::Response>& response);

  void setStreamProfileCallback(const std::shared_ptr<SetStreamProfile::Request>& request,
                                std::shared_ptr<SetStreamProfile::Response>& response);

  void setUserCalibParamsCallback(const std::shared_ptr<SetUserCalibParams::Request>& request,
                                  std::shared_ptr<SetUserCalibParams::Response>& response);

  void setIRLongExposureCallback(const std::shared_ptr<std_srvs::srv::SetBool::Request>& request,
                                 std::shared_ptr<std_srvs::srv::SetBool::Response>& response);

  void publishPointCloud(const std::shared_ptr<ob::FrameSet>& frame_set);

  void publishDepthPointCloud(const std::shared_ptr<ob::FrameSet>& frame_set);

  void publishColoredPointCloud(const std::shared_ptr<ob::FrameSet>& frame_set);

  void publishRawDepthImage(const std::shared_ptr<ob::Frame>& depth_frame);

  cv::Mat colorizeDepthImage(const cv::Mat& depth_image, const std::string& colorizer_mode);

  std::shared_ptr<ob::Frame> processDepthFrameFilter(std::shared_ptr<ob::Frame>& frame);

  std::shared_ptr<ob::Frame> processColorFrameFilter(std::shared_ptr<ob::Frame>& frame);

  std::shared_ptr<ob::Frame> processRightIrFrameFilter(std::shared_ptr<ob::Frame>& frame);

  std::shared_ptr<ob::Frame> processLeftIrFrameFilter(std::shared_ptr<ob::Frame>& frame);

  std::shared_ptr<ob::Frame> processIrFrameFilter(std::shared_ptr<ob::Frame>& frame);

  uint64_t getFrameTimestampUs(const std::shared_ptr<ob::Frame>& frame);

  void onNewFrameSetCallback(std::shared_ptr<ob::FrameSet> frame_set);

  std::shared_ptr<ob::Frame> softwareDecodeColorFrame(const std::shared_ptr<ob::Frame>& frame,
                                                      const stream_index_pair& stream_index);

  bool isColorFrameDecodeRequired(const std::shared_ptr<ob::Frame>& frame) const;

  bool decodeColorFrameToBuffer(const std::shared_ptr<ob::Frame>& frame, uint8_t* buffer);

  std::shared_ptr<ob::Frame> decodeIRMJPGFrame(const std::shared_ptr<ob::Frame>& frame);

  void onNewFrameCallback(const std::shared_ptr<ob::Frame>& frame,
                          const stream_index_pair& stream_index);

  void logFrameInfoOnce(const stream_index_pair& stream_index,
                        const std::shared_ptr<ob::VideoFrame>& video_frame);

  void publishMetadata(const std::shared_ptr<ob::Frame>& frame,
                       const stream_index_pair& stream_index, const std_msgs::msg::Header& header);

  std::string createFrameMetadataJson(const std::shared_ptr<ob::Frame>& frame) const;

  void onNewColorFrameCallback();

  void onNewLeftColorFrameCallback();

  void onNewRightColorFrameCallback();

  void saveImageToFile(const stream_index_pair& stream_index, const cv::Mat& raw_image,
                       const cv::Mat& image_to_save, const sensor_msgs::msg::Image& image_msg,
                       const std::shared_ptr<ob::Frame>& frame);

  void onNewIMUFrameSyncOutputCallback(const std::shared_ptr<ob::Frame>& accelframe,
                                       const std::shared_ptr<ob::Frame>& gryoframe,
                                       int64_t arrival_system_us);

  void onNewIMUFrameCallback(const std::shared_ptr<ob::Frame>& frame,
                             const stream_index_pair& stream_index);

  void setDefaultIMUMessage(sensor_msgs::msg::Imu& imu_msg);

  sensor_msgs::msg::Imu createUnitIMUMessage(const IMUData& accel_data, const IMUData& gyro_data);

  void FillImuDataLinearInterpolation(const IMUData& imu_data,
                                      std::deque<sensor_msgs::msg::Imu>& imu_msgs);

  void FillImuDataCopy(const IMUData& imu_data, std::deque<sensor_msgs::msg::Imu>& imu_msgs);

  bool setupFormatConvertType(OBFormat format);
  bool setupFormatConvertType(OBFormat format, ob::FormatConvertFilter& filter);
  bool hasCompressedImageSubscriber(const stream_index_pair& stream_index) const;
  void publishCompressedColorImage(const std::shared_ptr<ob::Frame>& frame,
                                   const stream_index_pair& stream_index,
                                   const rclcpp::Time& timestamp, const std::string& frame_id);

  orbbec_camera_msgs::msg::IMUInfo createIMUInfo(const stream_index_pair& stream_index);

  static bool isGemini435LePID(uint32_t pid);
  static bool isPublishMetaData(uint32_t pid);
  static bool isDabaiASeriesForHwD2C(uint32_t pid);
  static bool isLingBotSupportedPID(uint32_t pid);

  static bool isDepthWorkModeDevices(uint32_t pid);
  static bool isnotLaserDevices(uint32_t pid);

  void setupDepthPostProcessFilter();
  void setupColorPostProcessFilter();
  void setupIrPostProcessFilter();
  void setupRightIrPostProcessFilter();
  void setupLeftIrPostProcessFilter();
  void setupUndistortionFilters();
  bool shouldUseHwD2CColorUndistortion() const;
  void configureHwD2CColorUndistortion(const std::shared_ptr<ob::Frame>& depth_frame);
  void applyHwD2CColorUndistortion(std::shared_ptr<ob::FrameSet>& frame_set,
                                   const std::shared_ptr<ob::Frame>& depth_frame);

  // interleave AE
  int init_interleave_hdr_param();
  int init_interleave_laser_param();

  // Set ROI
  void setColorAutoExposureROI();
  void setDepthAutoExposureROI();

  void setDisparitySearchOffset();

  bool isWriteCustomerDataSuccess() const;

 private:
  std::atomic_bool write_customer_data_success_{false};
  std::atomic_bool user_calibration_ready_{false};
  // New state flags to make clean() and rebootDevice() idempotent and thread-safe
  std::atomic_bool cleaning_{false};
  rclcpp::Node* node_ = nullptr;
  std::shared_ptr<ob::Device> device_ = nullptr;
  std::shared_ptr<Parameters> parameters_ = nullptr;
  rclcpp::Logger logger_;
  std::atomic_bool is_running_{false};
  std::unique_ptr<ob::Pipeline> pipeline_ = nullptr;
  std::unique_ptr<ob::Pipeline> imuPipeline_ = nullptr;
  std::atomic_bool pipeline_started_{false};
  std::string camera_name_ = "camera";
  std::string accel_gyro_frame_id_ = "camera_accel_gyro_optical_frame";
  const std::string imu_frame_id_ = "camera_gyro_frame";
  std::shared_ptr<ob::Config> pipeline_config_ = nullptr;
  std::map<stream_index_pair, std::shared_ptr<ob::Sensor>> sensors_;
  std::map<stream_index_pair, ob_camera_intrinsic> stream_intrinsics_;
  std::map<stream_index_pair, sensor_msgs::msg::CameraInfo> camera_infos_;
  std::map<stream_index_pair, OBCameraParam> ob_camera_param_;
  std::map<stream_index_pair, OBExtrinsic> depth_to_other_extrinsics_;
  std::map<stream_index_pair, rclcpp::Publisher<orbbec_camera_msgs::msg::Extrinsics>::SharedPtr>
      depth_to_other_extrinsics_publishers_;
  std::map<stream_index_pair, rclcpp::Publisher<orbbec_camera_msgs::msg::Metadata>::SharedPtr>
      metadata_publishers_;
  std::map<stream_index_pair, rclcpp::Publisher<orbbec_camera_msgs::msg::IMUInfo>::SharedPtr>
      imu_info_publishers_;
  std::map<stream_index_pair, int> width_;
  std::map<stream_index_pair, int> height_;
  std::map<stream_index_pair, int> fps_;
  std::map<stream_index_pair, std::string> frame_id_;
  std::map<stream_index_pair, std::string> optical_frame_id_;
  std::map<stream_index_pair, std::string> depth_aligned_frame_id_;
  std::string camera_link_frame_id_;
  bool depth_registration_ = false;
  std::map<stream_index_pair, std::string> image_qos_;
  std::map<stream_index_pair, std::string> image_qos_history_;
  std::map<stream_index_pair, int> image_qos_depth_;
  std::map<stream_index_pair, std::string> camera_info_qos_;
  std::map<stream_index_pair, ob_format> format_;
  std::map<stream_index_pair, std::string> format_str_;
  std::map<stream_index_pair, int> image_format_;
  std::map<stream_index_pair, std::vector<std::shared_ptr<ob::VideoStreamProfile>>>
      supported_profiles_;
  std::map<stream_index_pair, std::shared_ptr<ob::StreamProfile>> stream_profile_;
  stream_index_pair base_stream_ = DEPTH;
  std::map<stream_index_pair, uint32_t> seq_;
  std::map<stream_index_pair, cv::Mat> images_;
  std::map<stream_index_pair, std::string> encoding_;
  std::map<stream_index_pair, int> unit_step_size_;
  std::vector<int> compression_params_;
  ob::FormatConvertFilter format_convert_filter_;
  ob::FormatConvertFilter format_convert_filter_left_;
  ob::FormatConvertFilter format_convert_filter_right_;

  std::map<stream_index_pair, bool> enable_stream_;
  std::map<stream_index_pair, bool> flip_stream_;
  std::map<stream_index_pair, bool> mirror_stream_;
  std::map<stream_index_pair, int> rotation_stream_;
  std::map<stream_index_pair, std::string> stream_name_;
  std::map<stream_index_pair, std::shared_ptr<image_publisher>> image_publishers_;
  std::map<stream_index_pair, rclcpp::Publisher<sensor_msgs::msg::CompressedImage>::SharedPtr>
      compressed_image_publishers_;
  std::map<stream_index_pair, rclcpp::Publisher<sensor_msgs::msg::CameraInfo>::SharedPtr>
      camera_info_publishers_;
  std::map<stream_index_pair, bool> frame_info_logged_;
  std::mutex frame_info_logged_mutex_;
  std::shared_ptr<image_publisher> depth_unaligned_publisher_;

  std::map<stream_index_pair, rclcpp::Service<GetInt32>::SharedPtr> get_exposure_srv_;
  std::map<stream_index_pair, rclcpp::Service<SetInt32>::SharedPtr> set_exposure_srv_;
  std::map<stream_index_pair, rclcpp::Service<GetInt32>::SharedPtr> get_gain_srv_;
  std::map<stream_index_pair, rclcpp::Service<SetInt32>::SharedPtr> set_gain_srv_;
  std::map<stream_index_pair, rclcpp::Service<SetBool>::SharedPtr> toggle_sensor_srv_;
  std::map<stream_index_pair, rclcpp::Service<SetBool>::SharedPtr> set_mirror_srv_;
  std::map<stream_index_pair, rclcpp::Service<SetBool>::SharedPtr> set_flip_srv_;
  std::map<stream_index_pair, rclcpp::Service<SetInt32>::SharedPtr> set_rotation_srv_;
  rclcpp::Service<GetInt32>::SharedPtr get_white_balance_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_white_balance_srv_;
  rclcpp::Service<GetInt32>::SharedPtr get_color_wb_ctrl_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_color_wb_ctrl_srv_;
  rclcpp::Service<GetInt32>::SharedPtr get_auto_white_balance_srv_;
  rclcpp::Service<SetBool>::SharedPtr set_auto_white_balance_srv_;
  rclcpp::Service<GetInt32>::SharedPtr get_ae_awb_status_srv_;
  rclcpp::Service<GetAwbGain>::SharedPtr get_awb_gain_srv_;
  rclcpp::Service<SetAwbGain>::SharedPtr set_awb_gain_srv_;
  rclcpp::Service<GetString>::SharedPtr get_sdk_version_srv_;
  rclcpp::Service<SetString>::SharedPtr switch_ir_camera_srv_;
  rclcpp::Service<SetString>::SharedPtr export_config_json_srv_;
  rclcpp::Service<SetString>::SharedPtr write_customerdata_srv_;
  rclcpp::Service<GetString>::SharedPtr read_customerdata_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_ir_long_exposure_srv_;
  std::map<stream_index_pair, rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr>
      set_auto_exposure_srv_;
  std::map<stream_index_pair, rclcpp::Service<SetArrays>::SharedPtr> set_ae_roi_srv_;
  rclcpp::Service<GetDeviceInfo>::SharedPtr get_device_srv_;
  rclcpp::Service<GetDeviceConfig>::SharedPtr get_device_config_srv_;
  rclcpp::Service<GetActionConfig>::SharedPtr get_action_config_srv_;
  rclcpp::Service<SetActionConfig>::SharedPtr set_action_config_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_laser_enable_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_ldp_enable_srv_;
  rclcpp::Service<orbbec_camera_msgs::srv::GetBool>::SharedPtr get_ldp_status_srv_;
  rclcpp::Service<orbbec_camera_msgs::srv::GetBool>::SharedPtr get_laser_status_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_ptp_config_srv_;
  rclcpp::Service<orbbec_camera_msgs::srv::GetBool>::SharedPtr get_ptp_config_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_flood_enable_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_fan_work_mode_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr toggle_sensors_srv_;
  rclcpp::Service<GetInt32>::SharedPtr get_lrm_measure_distance_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_reset_timestamp_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_interleaver_laser_sync_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_sync_host_time_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr send_software_trigger_srv_;
  rclcpp::Service<SetFilter>::SharedPtr set_filter_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_point_cloud_decimation_srv_;
  rclcpp::Service<GetInt32>::SharedPtr get_point_cloud_decimation_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_disparity_range_mode_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_disparity_search_offset_srv_;
  rclcpp::Service<SetInt32>::SharedPtr set_sync_io_voltage_level_srv_;
  rclcpp::Service<orbbec_camera_msgs::srv::GetBool>::SharedPtr get_streams_enable_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr set_streams_enable_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr get_color_queue_stats_srv_;
  rclcpp::Service<SetString>::SharedPtr set_image_registration_mode_srv_;
  rclcpp::Service<SetStreamProfile>::SharedPtr set_stream_profile_srv_;
  rclcpp::Service<GetUserCalibParams>::SharedPtr get_user_calib_params_srv_;
  rclcpp::Service<SetUserCalibParams>::SharedPtr set_user_calib_params_srv_;
  rclcpp::Service<SetString>::SharedPtr set_ae_reference_stream_srv_;
  rclcpp::Service<SetString>::SharedPtr set_ae_strategy_srv_;

  bool enable_sync_output_accel_gyro_ = false;
  bool publish_tf_ = false;
  bool tf_published_ = false;
  std::shared_ptr<tf2_ros::StaticTransformBroadcaster> static_tf_broadcaster_ = nullptr;
  std::shared_ptr<tf2_ros::TransformBroadcaster> dynamic_tf_broadcaster_ = nullptr;
  std::vector<geometry_msgs::msg::TransformStamped> tf_msgs;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr depth_registration_cloud_pub_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr depth_cloud_pub_;
  bool enable_point_cloud_ = true;
  bool enable_colored_point_cloud_ = false;
  int point_cloud_decimation_filter_factor_ = 1;
  std::recursive_mutex point_cloud_mutex_;

  orbbec_camera_msgs::msg::DeviceInfo device_info_;
  std::string point_cloud_qos_;
  std::vector<geometry_msgs::msg::TransformStamped> static_tf_msgs_;
  std::shared_ptr<std::thread> tf_thread_ = nullptr;
  std::condition_variable tf_cv_;
  double tf_publish_rate_ = 10.0;
  std::unique_ptr<camera_info_manager::CameraInfoManager> ir_info_manager_ = nullptr;
  std::unique_ptr<camera_info_manager::CameraInfoManager> color_info_manager_ = nullptr;
  std::string color_info_url_;
  std::string ir_info_url_;
  std::optional<OBCameraParam> camera_param_;
  std::string colorizer_mode_ = "none";
  bool enable_d2c_viewer_ = false;
  std::unique_ptr<D2CViewer> d2c_viewer_ = nullptr;
  std::map<stream_index_pair, std::atomic_bool> save_images_;
  std::map<stream_index_pair, int> save_images_count_;
  std::mutex save_images_mutex_;
  int max_save_images_count_ = 10;
  std::atomic_bool save_point_cloud_{false};
  std::atomic_bool save_colored_point_cloud_{false};
  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr save_images_srv_;
  rclcpp::Service<std_srvs::srv::Empty>::SharedPtr save_point_cloud_srv_;
  std::string depth_filter_config_;
  bool enable_depth_filter_ = false;
  bool enable_color_auto_exposure_priority_ = false;
  bool enable_color_auto_exposure_ = true;
  bool enable_color_auto_white_balance_ = true;
  bool enable_depth_auto_exposure_priority_ = false;
  bool enable_ir_auto_exposure_ = true;
  bool enable_ir_long_exposure_ = false;
  bool enable_ldp_ = true;
  int ldp_power_level_ = -1;
  int color_rotation_ = -1;
  // color ae roi
  int color_ae_roi_left_ = -1;
  int color_ae_roi_top_ = -1;
  int color_ae_roi_right_ = -1;
  int color_ae_roi_bottom_ = -1;
  int color_ae_roi_last_width_ = -1;
  int color_ae_roi_last_height_ = -1;
  int color_exposure_ = -1;
  int color_gain_ = -1;
  int color_mjpeg_quality_ = -1;
  int color_white_balance_ = -1;
  int color_ae_max_exposure_ = -1;
  int color_ae_max_gain_ = -1;
  int color_brightness_ = -1;
  int color_roi_brightness_ = -1;
  int color_sharpness_ = -1;
  int color_gamma_ = -1;
  int color_saturation_ = -1;
  int color_contrast_ = -1;
  int color_hue_ = -1;
  int color_backlight_compensation_ = -1;
  bool color_anti_flicker_ = false;
  std::string color_powerline_freq_;
  std::string color_preset_;
  int color_denoising_level_ = -1;
  bool enable_color_decimation_filter_ = false;
  int color_decimation_filter_scale_ = -1;
  bool enable_left_color_decimation_filter_ = false;
  int left_color_decimation_filter_scale_ = -1;
  bool enable_right_color_decimation_filter_ = false;
  int right_color_decimation_filter_scale_ = -1;
  // depth ae roi
  int depth_ae_roi_left_ = -1;
  int depth_ae_roi_top_ = -1;
  int depth_ae_roi_right_ = -1;
  int depth_ae_roi_bottom_ = -1;
  int depth_ae_roi_last_width_ = -1;
  int depth_ae_roi_last_height_ = -1;
  int mean_intensity_set_point_ = -1;
  int depth_brightness_ = -1;
  int depth_exposure_ = -1;
  int depth_gain_ = -1;
  int ir_exposure_ = -1;
  int ir_gain_ = -1;
  int ir_ae_max_exposure_ = -1;
  int ir_brightness_ = -1;
  bool enable_right_ir_sequence_id_filter_ = false;
  int right_ir_sequence_id_filter_id_ = -1;
  bool enable_left_ir_sequence_id_filter_ = false;
  int left_ir_sequence_id_filter_id_ = -1;
  bool enable_frame_sync_ = false;
  // Only for Gemini2 device
  std::string disparity_to_depth_mode_;
  std::string depth_work_mode_;
  std::string preset_resolution_config_;
  OBMultiDeviceSyncMode sync_mode_ = OBMultiDeviceSyncMode::OB_MULTI_DEVICE_SYNC_MODE_FREE_RUN;
  std::string sync_mode_str_;
  int depth_delay_us_ = 0;
  int color_delay_us_ = 0;
  int trigger2image_delay_us_ = 0;
  int trigger_out_delay_us_ = 0;
  bool trigger_out_enabled_ = false;
  bool software_trigger_enabled_ = false;
  int frames_per_trigger_ = 1;
  bool enable_ptp_config_ = false;
  std::string depth_precision_str_;
  OB_DEPTH_PRECISION_LEVEL depth_precision_ = OB_PRECISION_0MM8;
  double depth_precision_float_ = 0.10;
  // IMU
  std::map<stream_index_pair, rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr> imu_publishers_;
  rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_gyro_accel_publisher_;
  std::atomic_bool imu_sync_output_start_{false};
  std::map<stream_index_pair, std::string> imu_rate_;
  std::map<stream_index_pair, std::string> imu_range_;
  std::map<stream_index_pair, std::string> imu_qos_;
  std::map<stream_index_pair, bool> imu_started_;
  double linear_accel_cov_ = 0.0001;
  double angular_vel_cov_ = 0.0001;
  std::deque<IMUData> imu_history_;
  IMUData accel_data_{ACCEL, {0, 0, 0}, -1.0};
  bool enable_accel_data_correction_ = true;
  bool enable_gyro_data_correction_ = true;
  // mjpeg decoder
  std::shared_ptr<JPEGDecoder> jpeg_decoder_ = nullptr;
  std::shared_ptr<JPEGDecoder> jpeg_decoder_left_ = nullptr;
  std::shared_ptr<JPEGDecoder> jpeg_decoder_right_ = nullptr;
  uint8_t* rgb_buffer_ = nullptr;
  uint8_t* rgb_buffer_left_ = nullptr;
  uint8_t* rgb_buffer_right_ = nullptr;
  size_t rgb_buffer_size_ = 0;
  size_t rgb_buffer_left_size_ = 0;
  size_t rgb_buffer_right_size_ = 0;
  bool is_left_color_frame_decoded_ = false;
  bool is_right_color_frame_decoded_ = false;
  bool is_color_frame_decoded_ = false;
  std::recursive_mutex device_lock_;
  struct QueuedColorFrame {
    std::shared_ptr<ob::FrameSet> frame_set;
    std::chrono::steady_clock::time_point enqueue_time;
  };
  struct ColorQueueStats {
    size_t max_queue_size = 0;
    uint64_t overflow_count = 0;
    double max_queue_wait_ms = 0.0;
  };
  struct ColorQueueStatsSnapshot {
    int capacity_frames = 0;
    size_t queue_size = 0;
    size_t max_queue_size = 0;
    uint64_t overflow_count = 0;
    double oldest_queue_wait_ms = 0.0;
    double max_queue_wait_ms = 0.0;
  };
  using ColorFrameQueue = std::queue<QueuedColorFrame>;
  void enqueueColorFrame(ColorFrameQueue& queue, std::mutex& mutex,
                         std::condition_variable& condition_variable, ColorQueueStats& stats,
                         int capacity_frames, const std::shared_ptr<ob::FrameSet>& frame_set,
                         const char* queue_name);
  ColorQueueStatsSnapshot getColorQueueStats(ColorFrameQueue& queue, std::mutex& mutex,
                                             ColorQueueStats& stats, int capacity_frames,
                                             bool reset);
  // For color
  ColorFrameQueue color_frame_queue_;
  ColorQueueStats color_frame_queue_stats_;
  int color_frame_queue_max_frames_ = 1;
  std::shared_ptr<std::thread> colorFrameThread_ = nullptr;
  std::atomic_bool stop_color_frame_threads_{false};
  std::mutex color_frame_queue_lock_;
  std::condition_variable color_frame_queue_cv_;

  // For left color
  ColorFrameQueue left_color_frame_queue_;
  ColorQueueStats left_color_frame_queue_stats_;
  int left_color_frame_queue_max_frames_ = 1;
  std::shared_ptr<std::thread> leftColorFrameThread_ = nullptr;
  std::mutex left_color_frame_queue_lock_;
  std::condition_variable left_color_frame_queue_cv_;

  // For right color
  ColorFrameQueue right_color_frame_queue_;
  ColorQueueStats right_color_frame_queue_stats_;
  int right_color_frame_queue_max_frames_ = 1;
  std::shared_ptr<std::thread> rightColorFrameThread_ = nullptr;
  std::mutex right_color_frame_queue_lock_;
  std::condition_variable right_color_frame_queue_cv_;

  bool ordered_pc_ = false;
  bool enable_depth_scale_ = true;
  int depth_decimation_factor_ = 1;
  int left_ir_decimation_factor_ = 1;
  int right_ir_decimation_factor_ = 1;
  std::string device_preset_;
  std::string device_preset_version_;
  // filter switch
  bool enable_decimation_filter_ = false;
  bool enable_hdr_merge_ = false;
  bool enable_sequence_id_filter_ = false;
  bool enable_disparity_to_depth_ = true;
  bool enable_threshold_filter_ = false;
  bool enable_hardware_noise_removal_filter_ = true;
  bool enable_noise_removal_filter_ = true;
  bool enable_spatial_filter_ = true;
  bool enable_temporal_filter_ = false;
  bool enable_hole_filling_filter_ = false;
  bool enable_edge_noise_removal_filter_ = false;
  bool enable_spatial_fast_filter_ = false;
  bool enable_spatial_moderate_filter_ = false;
  bool enable_false_positive_filter_ = false;
  bool enable_mgc_noise_removal_filter_ = false;
  bool enable_lut_noise_removal_filter_ = false;
  bool enable_disp_outliers_filter_ = false;

  // filter params
  int disp_outliers_filter_search_mode_ = -1;
  int decimation_filter_scale_ = -1;
  int sequence_id_filter_id_ = -1;
  int threshold_filter_max_ = -1;
  int threshold_filter_min_ = -1;
  float hardware_noise_removal_filter_threshold_ = -1.0;
  int noise_removal_filter_min_diff_ = -1;
  int noise_removal_filter_max_size_ = -1;
  float spatial_filter_alpha_ = -1;
  int spatial_filter_diff_threshold_ = -1;
  int spatial_filter_magnitude_ = -1;
  int spatial_filter_radius_ = -1;
  float temporal_filter_diff_threshold_ = -1.0;
  float temporal_filter_weight_ = -1.0;
  std::string hole_filling_filter_mode_;
  int hdr_merge_exposure_1_ = -1;
  int hdr_merge_gain_1_ = -1;
  int hdr_merge_exposure_2_ = -1;
  int hdr_merge_gain_2_ = -1;
  int gmsl_trigger_fd_ = -1;
  int gmsl_trigger_fps_ = -1;
  bool enable_gmsl_trigger_ = false;
  int spatial_fast_filter_radius_ = -1;
  int spatial_moderate_filter_radius_ = -1;
  int spatial_moderate_filter_diff_threshold_ = -1;
  int spatial_moderate_filter_magnitude_ = -1;
  rclcpp::Publisher<DepthFiltersStatus>::SharedPtr depth_filters_status_pub_;
  nlohmann::json filter_status_;
  std::string align_mode_ = "HW";
  std::unique_ptr<diagnostic_updater::Updater> diagnostic_updater_ = nullptr;
  double diagnostic_period_ = 0.0;
  bool enable_laser_ = false;
  std::unique_ptr<ob::Align> align_filter_ = nullptr;
  std::shared_ptr<ob::EnhancedDepthFilter> enhanced_depth_filter_ = nullptr;
  ob::FormatConvertFilter enhanced_depth_format_convert_filter_;
  std::mutex enhanced_depth_filter_mutex_;
  std::atomic_bool enable_enhanced_depth_{false};
  std::string enhanced_depth_model_path_;
  int enhanced_depth_confidence_threshold_ = -1;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr confidence_image_publisher_;
  cv::Mat confidence_image_;
  OBStreamType align_target_stream_ = OB_STREAM_COLOR;
  bool retry_on_usb3_detection_failure_ = false;
  bool config_json_loaded_ = false;
  std::unordered_set<std::string> initial_ros_params_;
  std::atomic_bool is_camera_node_initialized_{false};
  int laser_energy_level_ = -1;
  ob::PointCloudFilter depth_point_cloud_filter_;
  ob::PointCloudFilter color_point_cloud_filter_;
  std::optional<OBCalibrationParam> calibration_param_;
  std::optional<OBXYTables> xy_tables_;
  float* xy_table_data_ = nullptr;
  uint32_t xy_table_data_size_ = 0;
  uint8_t* rgb_point_cloud_buffer_ = nullptr;
  uint32_t rgb_point_cloud_buffer_size_ = 0;
  std::optional<OBXYTables> depth_xy_tables_;
  float* depth_xy_table_data_ = nullptr;
  uint32_t depth_xy_table_data_size_ = 0;
  uint8_t* depth_point_cloud_buffer_ = nullptr;
  uint32_t depth_point_cloud_buffer_size_ = 0;
  int min_depth_limit_ = 0;
  int max_depth_limit_ = 0;
  std::string time_domain_ = "global";  // device, system, global
  bool enable_frame_drop_log_ = false;
  std::string frame_timestamp_csv_file_;
  std::unique_ptr<TimestampCsvLogger> timestamp_csv_logger_;
  std::string exposure_range_mode_;
  std::string load_config_json_file_path_ = "";
  std::string export_config_json_file_path_ = "";
  // soft ware trigger
  rclcpp::TimerBase::SharedPtr software_trigger_timer_;
  rclcpp::TimerBase::SharedPtr lrm_obstacle_distance_timer_;
  rclcpp::TimerBase::SharedPtr diagnostic_timer_;
  rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr lrm_obstacle_distance_pub_;
  std::mutex diagnostic_mutex_;
  std::condition_variable diagnostic_cv_;
  bool diagnostic_running_ = false;
  std::chrono::milliseconds software_trigger_period_{33};
  bool enable_lrm_obstacle_distance_publish_ = false;
  double lrm_obstacle_distance_publish_rate_ = 10.0;
  bool enable_heartbeat_ = false;
  bool enable_firmware_log_ = false;
  int monitor_poll_interval_sec_ = -1;
  bool enable_fps_boost_ = false;
  std::map<stream_index_pair, bool> enable_undistortion_;
  std::shared_ptr<ob::UnDistortionFilter> hw_d2c_color_undistortion_filter_;
  bool hw_d2c_color_undistortion_configured_ = false;
  bool has_first_color_frame_ = false;
  bool use_intra_process_ = false;
  // True when device_ is an ob::PlaybackDevice. Real-device-only hardware
  // tuning (heartbeat, USB3 retry, laser, sync config, etc.) is skipped in
  // setupDevices() for playback devices since those SDK components aren't
  // registered for a recorded .bag file.
  bool is_playback_device_ = false;
  std::string cloud_frame_id_;
  std::mutex depth_filter_mutex_;
  std::vector<std::shared_ptr<ob::Filter>> depth_filter_list_;
  std::vector<std::shared_ptr<ob::Filter>> color_filter_list_;
  std::vector<std::shared_ptr<ob::Filter>> left_color_filter_list_;
  std::vector<std::shared_ptr<ob::Filter>> right_color_filter_list_;
  std::vector<std::shared_ptr<ob::Filter>> ir_filter_list_;
  std::vector<std::shared_ptr<ob::Filter>> left_ir_filter_list_;
  std::vector<std::shared_ptr<ob::Filter>> right_ir_filter_list_;

  // interleave AE
  std::string interleave_ae_mode_;  // hdr or laser
  bool interleave_frame_enable_ = false;
  bool interleave_skip_enable_ = false;
  int interleave_skip_index_ = -1;

  // hdr and laser interleave params
  int hdr_index1_laser_control_ = -1;
  int hdr_index1_depth_exposure_ = -1;
  int hdr_index1_depth_gain_ = -1;
  int hdr_index1_ir_brightness_ = -1;
  int hdr_index1_ir_ae_max_exposure_ = -1;
  int hdr_index0_laser_control_ = -1;
  int hdr_index0_depth_exposure_ = -1;
  int hdr_index0_depth_gain_ = -1;
  int hdr_index0_ir_brightness_ = -1;
  int hdr_index0_ir_ae_max_exposure_ = -1;

  int laser_index1_laser_control_ = -1;
  int laser_index1_depth_exposure_ = -1;
  int laser_index1_depth_gain_ = -1;
  int laser_index1_ir_brightness_ = -1;
  int laser_index1_ir_ae_max_exposure_ = -1;
  int laser_index0_laser_control_ = -1;
  int laser_index0_depth_exposure_ = -1;
  int laser_index0_depth_gain_ = -1;
  int laser_index0_ir_brightness_ = -1;
  int laser_index0_ir_ae_max_exposure_ = -1;

  int disparity_range_mode_ = -1;
  int disparity_search_offset_ = -1;
  bool disparity_offset_config_ = false;
  int offset_index0_ = -1;
  int offset_index1_ = -1;
  int sync_io_voltage_level_ = -1;

  std::string frame_aggregate_mode_ = "ANY";  // # full_frame, color_frame, ANY or disable

  bool show_fps_enable_ = false;
  bool enable_publish_extrinsic_ = false;
  std::unique_ptr<FpsCounter> fps_counter_color_{nullptr};
  std::unique_ptr<FpsCounter> fps_counter_left_color_{nullptr};
  std::unique_ptr<FpsCounter> fps_counter_right_color_{nullptr};
  std::unique_ptr<FpsCounter> fps_counter_depth_{nullptr};
  std::unique_ptr<FpsCounter> fps_counter_left_ir_{nullptr};
  std::unique_ptr<FpsCounter> fps_counter_right_ir_{nullptr};

  std::map<std::string, std::shared_ptr<StreamStatusTracker>> stream_status_trackers_;
  mutable std::mutex stream_status_mutex_;

  std::string intra_camera_sync_reference_ = "";
  std::string ae_reference_stream_;
  std::string ae_strategy_;
  int pid_ = 0;
};
}  // namespace orbbec_camera
