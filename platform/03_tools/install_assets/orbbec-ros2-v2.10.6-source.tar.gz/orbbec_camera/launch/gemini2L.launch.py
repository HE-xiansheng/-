import os
import yaml
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import ComposableNodeContainer, Node, PushRosNamespace
from launch_ros.descriptions import ComposableNode


def load_yaml(file_path):
    try:
        with open(file_path, "r") as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(f"[orbbec_camera] Failed to load yaml '{file_path}': {e}")
        return {}


def merge_params(default_params, yaml_params):
    if not isinstance(yaml_params, dict):
        print("[orbbec_camera] YAML parameters should be a dictionary.")
        return default_params
    for key, value in yaml_params.items():
        default_params[key] = value
    return default_params


def resolve_config_file_path(config_file_path: str) -> str:
    if not config_file_path:
        return config_file_path
    if os.path.isabs(config_file_path) and os.path.exists(config_file_path):
        return config_file_path
    if os.path.exists(config_file_path):
        return config_file_path
    config_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "config"))
    candidate = os.path.join(config_dir, config_file_path)
    if os.path.exists(candidate):
        return candidate
    return config_file_path


def convert_value(value):
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            pass
        try:
            return float(value)
        except ValueError:
            pass
        if value.lower() == "true":
            return True
        if value.lower() == "false":
            return False
    return value


def load_parameters(context, args):
    default_params = {arg.name: LaunchConfiguration(arg.name).perform(context) for arg in args}
    config_file_path = resolve_config_file_path(
        LaunchConfiguration("config_file_path").perform(context)
    )
    if config_file_path:
        yaml_params = load_yaml(config_file_path)
        default_params = merge_params(default_params, yaml_params)
    skip_convert = {"config_file_path", "usb_port", "serial_number", 'bag_record_filename', 'bag_filename',
                    "depth_colorizer_mode"}

    return {
        key: (value if key in skip_convert else convert_value(value))
        for key, value in default_params.items()
    }


def generate_launch_description():
    args = [
        DeclareLaunchArgument("camera_name", default_value="camera"),
        DeclareLaunchArgument("depth_registration", default_value="false"),
        DeclareLaunchArgument("serial_number", default_value=""),
        DeclareLaunchArgument("usb_port", default_value=""),
        DeclareLaunchArgument("device_num", default_value="1"),
        DeclareLaunchArgument("bag_record_filename", default_value=""),
        DeclareLaunchArgument("bag_filename", default_value=""),
        DeclareLaunchArgument("bag_loop", default_value="false"),
        DeclareLaunchArgument("uvc_backend", default_value="libuvc"),  # libuvc or v4l2
        DeclareLaunchArgument("product_id", default_value=""),
        DeclareLaunchArgument("enable_point_cloud", default_value="true"),
        DeclareLaunchArgument("cloud_frame_id", default_value=""),
        DeclareLaunchArgument("enable_colored_point_cloud", default_value="false"),
        DeclareLaunchArgument("point_cloud_qos", default_value="default"),
        DeclareLaunchArgument("connection_delay", default_value="100"),
        DeclareLaunchArgument("color_frame_queue_max_frames", default_value="1"),
        DeclareLaunchArgument("color_width", default_value="1280"),
        DeclareLaunchArgument("color_height", default_value="800"),
        DeclareLaunchArgument("color_fps", default_value="30"),
        DeclareLaunchArgument("color_format", default_value="MJPG"),
        DeclareLaunchArgument("enable_color", default_value="true"),
        DeclareLaunchArgument("color_flip", default_value="false"),
        DeclareLaunchArgument("color_qos", default_value="default"),
        DeclareLaunchArgument("color_qos_history", default_value="default"),
        DeclareLaunchArgument("color_qos_depth", default_value="-1"),
        DeclareLaunchArgument("color_camera_info_qos", default_value="default"),
        DeclareLaunchArgument("enable_color_auto_exposure", default_value="true"),
        DeclareLaunchArgument("color_ae_max_exposure", default_value="-1"),
        DeclareLaunchArgument("color_ae_max_gain", default_value="-1"),
        DeclareLaunchArgument("color_exposure", default_value="-1"),
        DeclareLaunchArgument("color_gain", default_value="-1"),
        DeclareLaunchArgument("enable_color_auto_white_balance", default_value="true"),
        DeclareLaunchArgument("color_white_balance", default_value="-1"),
        DeclareLaunchArgument("color_brightness", default_value="-1"),
        DeclareLaunchArgument("color_denoising_level", default_value="-1"),
        DeclareLaunchArgument('enable_color_decimation_filter', default_value='false'),
        DeclareLaunchArgument('color_decimation_filter_scale', default_value='-1'),
        DeclareLaunchArgument("depth_width", default_value="1280"),
        DeclareLaunchArgument("depth_height", default_value="800"),
        DeclareLaunchArgument("depth_fps", default_value="30"),
        DeclareLaunchArgument("depth_format", default_value="Y16"),
        DeclareLaunchArgument("enable_depth", default_value="true"),
        DeclareLaunchArgument("depth_flip", default_value="false"),
        DeclareLaunchArgument("depth_qos", default_value="default"),
        DeclareLaunchArgument("depth_qos_history", default_value="default"),
        DeclareLaunchArgument("depth_qos_depth", default_value="-1"),
        DeclareLaunchArgument("depth_camera_info_qos", default_value="default"),
        DeclareLaunchArgument("ir_width", default_value="640"),
        DeclareLaunchArgument("ir_height", default_value="400"),
        DeclareLaunchArgument("ir_fps", default_value="15"),
        DeclareLaunchArgument("ir_format", default_value="Y8"),
        DeclareLaunchArgument("enable_ir", default_value="true"),
        DeclareLaunchArgument("ir_flip", default_value="false"),
        DeclareLaunchArgument("ir_qos", default_value="default"),
        DeclareLaunchArgument("ir_qos_history", default_value="default"),
        DeclareLaunchArgument("ir_qos_depth", default_value="-1"),
        DeclareLaunchArgument("ir_camera_info_qos", default_value="default"),
        DeclareLaunchArgument("enable_ir_auto_exposure", default_value="true"),
        DeclareLaunchArgument("ir_ae_max_exposure", default_value="-1"),
        DeclareLaunchArgument("ir_exposure", default_value="-1"),
        DeclareLaunchArgument("ir_gain", default_value="-1"),
        DeclareLaunchArgument("ir_brightness", default_value="-1"),
        DeclareLaunchArgument("enable_sync_output_accel_gyro", default_value="false"),
        DeclareLaunchArgument("enable_accel", default_value="false"),
        DeclareLaunchArgument("accel_rate", default_value="100hz"),
        DeclareLaunchArgument("accel_range", default_value="4g"),
        DeclareLaunchArgument("enable_gyro", default_value="false"),
        DeclareLaunchArgument("gyro_rate", default_value="100hz"),
        DeclareLaunchArgument("gyro_range", default_value="1000dps"),
        DeclareLaunchArgument("linear_accel_cov", default_value="0.01"),
        DeclareLaunchArgument("angular_vel_cov", default_value="0.01"),
        DeclareLaunchArgument("publish_tf", default_value="true"),
        DeclareLaunchArgument("tf_publish_rate", default_value="0.0"),
        DeclareLaunchArgument("ir_info_url", default_value=""),
        DeclareLaunchArgument("color_info_url", default_value=""),
        DeclareLaunchArgument("log_level", default_value="info"),
        DeclareLaunchArgument("log_file_name", default_value=""),
        DeclareLaunchArgument("enable_publish_extrinsic", default_value="false"),
        DeclareLaunchArgument("enable_d2c_viewer", default_value="false"),
        DeclareLaunchArgument("depth_colorizer_mode", default_value="none"),
        DeclareLaunchArgument("disparity_to_depth_mode", default_value="SW"),
        DeclareLaunchArgument("enable_ldp", default_value="true"),
        DeclareLaunchArgument("enable_decimation_filter", default_value="false"),
        DeclareLaunchArgument("enable_threshold_filter", default_value="false"),
        DeclareLaunchArgument("enable_noise_removal_filter", default_value="true"),
        DeclareLaunchArgument("enable_spatial_filter", default_value="false"),
        DeclareLaunchArgument("enable_temporal_filter", default_value="false"),
        DeclareLaunchArgument("enable_disparity_to_depth", default_value="true"),
        DeclareLaunchArgument("enable_hole_filling_filter", default_value="false"),
        DeclareLaunchArgument("decimation_filter_scale", default_value="-1"),
        DeclareLaunchArgument("threshold_filter_max", default_value="-1"),
        DeclareLaunchArgument("threshold_filter_min", default_value="-1"),
        DeclareLaunchArgument("noise_removal_filter_min_diff", default_value="256"),
        DeclareLaunchArgument("noise_removal_filter_max_size", default_value="200"),
        DeclareLaunchArgument("spatial_filter_alpha", default_value="-1.0"),
        DeclareLaunchArgument("spatial_filter_diff_threshold", default_value="-1"),
        DeclareLaunchArgument("spatial_filter_magnitude", default_value="-1"),
        DeclareLaunchArgument("spatial_filter_radius", default_value="-1"),
        DeclareLaunchArgument("temporal_filter_diff_threshold", default_value="-1.0"),
        DeclareLaunchArgument("temporal_filter_weight", default_value="-1.0"),
        DeclareLaunchArgument("hole_filling_filter_mode", default_value=""),
        # Depth work mode support is as follows:
        # Unbinned Dense Default
        # Unbinned Sparse Default
        # Binned Sparse Default
        DeclareLaunchArgument("depth_work_mode", default_value="Unbinned Dense Default"),
        DeclareLaunchArgument("sync_mode", default_value="standalone"),
        DeclareLaunchArgument("depth_delay_us", default_value="0"),
        DeclareLaunchArgument("color_delay_us", default_value="0"),
        DeclareLaunchArgument("trigger2image_delay_us", default_value="0"),
        DeclareLaunchArgument("trigger_out_delay_us", default_value="0"),
        DeclareLaunchArgument("trigger_out_enabled", default_value="false"),
        DeclareLaunchArgument("enable_frame_sync", default_value="true"),
        DeclareLaunchArgument("ordered_pc", default_value="false"),
        DeclareLaunchArgument("enable_depth_scale", default_value="true"),
        DeclareLaunchArgument("align_mode", default_value="HW"),
        DeclareLaunchArgument("retry_on_usb3_detection_failure", default_value="false"),
        DeclareLaunchArgument("laser_energy_level", default_value="-1"),
        DeclareLaunchArgument("enable_heartbeat", default_value="false"),
        DeclareLaunchArgument("enable_firmware_log", default_value="false"),
        DeclareLaunchArgument("monitor_poll_interval_sec", default_value="-1"),
        DeclareLaunchArgument("time_domain", default_value="global"),
        DeclareLaunchArgument("timestamp_clock_type", default_value=""),  # realtime or monotonic, default is realtime.
        DeclareLaunchArgument("enable_frame_drop_log", default_value="false"),
        DeclareLaunchArgument("frame_timestamp_csv_file", default_value=""),
        DeclareLaunchArgument("enable_color_undistortion", default_value="false"),
        DeclareLaunchArgument("enable_depth_undistortion", default_value="false"),
        DeclareLaunchArgument("enable_ir_undistortion", default_value="false"),
        DeclareLaunchArgument("config_file_path", default_value=""),
    ]

    def get_params(context, args):
        return [load_parameters(context, args)]

    def create_node_action(context, args):
        params = get_params(context, args)
        ros_distro = os.environ.get("ROS_DISTRO", "humble")
        if ros_distro == "foxy":
            return [
                Node(
                    package="orbbec_camera",
                    executable="orbbec_camera_node",
                    name="ob_camera_node",
                    namespace=LaunchConfiguration("camera_name"),
                    parameters=params,
                    output="log",
                )
            ]
        return [
            GroupAction(
                [
                    PushRosNamespace(LaunchConfiguration("camera_name")),
                    ComposableNodeContainer(
                        name="camera_container",
                        namespace="",
                        package="rclcpp_components",
                        executable="component_container",
                        composable_node_descriptions=[
                            ComposableNode(
                                package="orbbec_camera",
                                plugin="orbbec_camera::OBCameraNodeDriver",
                                name=LaunchConfiguration("camera_name"),
                                parameters=params,
                            ),
                        ],
                        output="log",
                    ),
                ]
            )
        ]

    return LaunchDescription(
        args + [OpaqueFunction(function=lambda context: create_node_action(context, args))]
    )
